//action.js
//获取应用实例
var app = getApp()
Page({
  data: {
    actionpic: 'https://upload-images.jianshu.io/upload_images/25027716-c52463225b6d6863.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
    actionapic: 'https://upload-images.jianshu.io/upload_images/25027716-f0835577b88c13b3.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
    actionbpic: 'https://upload-images.jianshu.io/upload_images/25027716-7477e8fcd6f355f6.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240', 
    actioncpic: 'https://upload-images.jianshu.io/upload_images/25027716-4baae34b4ea04435.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
    actiondpic: 'https://upload-images.jianshu.io/upload_images/25027716-83a2e92ba5e1474c.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
    actionepic: 'https://upload-images.jianshu.io/upload_images/25027716-9fccd6c1dbf4d04a.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
    actionfpic: 'https://upload-images.jianshu.io/upload_images/25027716-315f07ddc85fd370.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
    actiongpic: 'https://upload-images.jianshu.io/upload_images/25027716-6fabe95da81a6d28.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
    actionhpic: 'https://upload-images.jianshu.io/upload_images/25027716-82a5d943fea9fc06.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
    actionipic: 'https://upload-images.jianshu.io/upload_images/25027716-3c7086144485519f.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
    actionjpic: 'https://upload-images.jianshu.io/upload_images/25027716-422bab1077eb9fee.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
    actionkpic: 'https://upload-images.jianshu.io/upload_images/25027716-3ad97a2232c55eb3.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
    actionlpic: 'https://upload-images.jianshu.io/upload_images/25027716-140678bba54e5c74.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
    actionmpic: 'https://upload-images.jianshu.io/upload_images/25027716-a5203b946385999d.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
  },




});