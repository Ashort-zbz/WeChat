//teacher.js
//获取应用实例
var app = getApp()
Page({
  data:{
    trimg1:'https://upload-images.jianshu.io/upload_images/25027716-a0959b20f1ed67fa.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
    trimg2:'https://upload-images.jianshu.io/upload_images/25027716-50f6d852d9b26b48.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
    trimg3:'https://upload-images.jianshu.io/upload_images/25027716-3979eaf98fcd8c8a.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
    trimg4:'https://upload-images.jianshu.io/upload_images/25027716-77cb5a91739aa723.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
    trimg5:'https://upload-images.jianshu.io/upload_images/25027716-23afc091af51edaf.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
    trimg6:'https://upload-images.jianshu.io/upload_images/25027716-c4864a77b66dd765.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
    trimg7:'https://upload-images.jianshu.io/upload_images/25027716-97377debb7f87fb7.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
    trimg8:'https://upload-images.jianshu.io/upload_images/25027716-3925c9fc336e82ce.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
    trimg9:'https://upload-images.jianshu.io/upload_images/25027716-2df7e5484c0e57f4.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
    trimg10:'https://upload-images.jianshu.io/upload_images/25027716-04ad517cc5b5a0c4.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
  }



})