//teacherlist.js
//获取应用实例
var app = getApp()
Page({
  data: {
    trimg: 'http://img.xdf.cn/TeacherIMG/2011/20110412/TCCQ09120110412170811_big.jpg'
  }



})