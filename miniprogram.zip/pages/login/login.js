// pages/login/login.js
const app = getApp()
const date = new Date();


Page({

  /**
   * 页面的初始数据
   */
  data: {
  name:0,
  password:''
  },
  //输入用户名
  inputName: function (event) {
    this.setData({
      name:event.detail.value
    })//将用户输入的账号放到变量里面
  },
  //输入密码
  inputPassword(event) {
    this.setData({
      password:event.detail.value
    })//将用户输入的密码放到变量里面
  },
  //登陆函数
  login:function(){
    wx.cloud.init({
      env: 'lhy-3gxyu8ezcfb70595',
      traceUser:true
    })
    let that = this;
    const db = wx.cloud.database()
    //登陆获取用户信息
    db.collection('admin').get({
      success: (res) => {
        let admin = res.data;
         console.log(res.data);
        for (let i = 0; i < admin.length; i++) {  //遍历数据库对象集合
          if (name == admin[i].account) { //用户名存在
            if (password !== admin[i].password) {  //判断密码是否正确
              wx.showToast({
                title: '密码错误！！',
                icon: 'none',
                duration: 2500
              })
            } else {
              console.log('登陆成功！')
              wx.showToast({
                title: '登陆成功！！',
                icon: 'success',
                duration: 2500
              })

              wx.switchTab({
                url: '/pages/index/index',//这里是成功登录后跳转的页面
              })
            }
          } else {   //不存在
            wx.showToast({
              title: '无此用户名！！',
              icon: 'none',
              duration: 2500
            })
          }
        }
      }
    })
  }
})
