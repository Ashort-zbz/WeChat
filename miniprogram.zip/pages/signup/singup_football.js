// pages/signup/singup_football.js

const app = getApp()
const date = new Date();
const years = []
for (let i = 2018; i <= date.getFullYear() + 5; i++) {
  years.push("" + i);
}
Page({

  /**
   * 页面的初始数据
   */
  data: {
    openid: '',
    countId:'',
    name:'',
    stuId:'',
    stuGrade:'2020',
    stuMajor:'',
    ID:'',
    phnoNum:'',
    qqNum:'',
    date:"2020"
  },

 /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if (app.globalData.openid) {
      this.setData({
        openid: app.globalData.openid,
      })
    }
  },
  /*
    *input事件
    */
  inputname(e){
    this.setData({
      name:e.detail.value
    })
  },inputstuId(e){
    this.setData({
      stuId:e.detail.value
    })
  },
  bindDateChange: function(e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      date: e.detail.value,
      stuGrade:date.getFullYear
    })
  },
  inputstuMajor(e){
    this.setData({
      stuMajor:e.detail.value
    })
  },inputId(e){
    this.setData({
      ID:e.detail.value
    })
  },inputphnoNum(e){
    this.setData({
      phnoNum:e.detail.value
    })
  },inputqqNum(e){
    this.setData({
      qqNum:e.detail.value
    })
  },

  onAdd: function () {
    wx.cloud.init({
      env: 'lhy-3gxyu8ezcfb70595',
      traceUser:true
    })
    const db = wx.cloud.database()
    db.collection('user').add({
      data: {
        name:this.data.name,
        stuId:this.data.stuId,
        stuMajor:this.data.stuMajor,
        ID:this.data.ID,
        phnoNum:this.data.phnoNum,
        qqNum:this.data.qqNum
      },
      success: res => {
        // 在返回结果中会包含新创建的记录的 _id
        this.setData({
          countId: res._id,
          name,
          stuId,
          stuMajor,
          ID,
          phnoNum,
          qqNum,
        })
        wx.showToast({
          title: '新增记录成功',
        })
        console.log('[数据库] [新增记录] 成功，记录 _id: ', res._id)
      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '新增记录失败'
        })
        console.error('[数据库] [新增记录] 失败：', err)
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})