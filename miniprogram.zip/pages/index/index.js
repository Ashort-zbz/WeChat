//index.js
//获取应用实例
var app = getApp()
Page({
  data: {
    a1src:'../../image/a1.png',
    a2src: '../../image/a2.png',
    a3src: '../../image/a3.png',
    a4src: '../../image/a4.png',
    signupimg:'../../image/signup.png',
    imgsrc:'https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=1642557086,4148216018&fm=26&gp=0.jpg',
    iconsrc:'../../image/usercount.png',
    jtsrc:'../../image/icon-jt.png',
    imgUrls: [
      {url:'https://mmbiz.qpic.cn/mmbiz_jpg/zkkG3OIx3XrTWEsPF6oKG00RdibEV5Avd1VwD0Q1YbZ9rflQnPBeYQoSaJ7qhfHMoXPZDZgDNUN2bMMucd4erNA/640?wx_fmt=jpeg&tp=webp&wxfrom=5&wx_lazy=1&wx_co=1',
        link:'https://mp.weixin.qq.com/s/wVTsMUIP-1e3F5MmBTdgCw'},
      {url:'https://mmbiz.qpic.cn/mmbiz_jpg/zkkG3OIx3XrTWEsPF6oKG00RdibEV5AvdoECeic0IAsKIDfbbibiceRUSxuGM2epd9p7Js8XX4nW1djBb2CO4cacgQ/640?wx_fmt=jpeg&tp=webp&wxfrom=5&wx_lazy=1&wx_co=1',
        link:'https://mp.weixin.qq.com/s/cpsc2kxHU4ukX1Tkww_djQ'},
      {url:'https://mmbiz.qpic.cn/mmbiz_jpg/zkkG3OIx3XrTWEsPF6oKG00RdibEV5AvdE2A7Mib35QKQAEwibIdAqo7MqZFnvrmqSbuas8Dnu7AoeWStzS8Kqjkg/640?wx_fmt=jpeg&tp=webp&wxfrom=5&wx_lazy=1&wx_co=1',
        link:'https://mp.weixin.qq.com/s/TfV35QOpII26SrZvS7anwg'}
    ],
    indicatorDots: true,
    autoplay: true,
    interval: 5000,
    duration: 1000 
  },

  bindViewTap: function (event) {
    wx.navigateTo({
      url: event.target.dataset.link
    })
  },
  onShareAppMessage: function (res) {
    if (res.from === 'button') {
      // 来自页面内转发按钮
      console.log(res.target)
    }
    return {
      title: '信息学院体育部',
      path: '/pages/index/index',
      success: function (res) {
        // 转发成功
        console.log("转发成功")
      },
      fail: function (res) {
        // 转发失败
        onsole.log("转发失败")
      }
    }
  }
})
