var app = getApp()
Page({
  data: {
    actionpic: 'https://upload-images.jianshu.io/upload_images/25027716-2ae53672d4bd5d8a.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
    actionapic: 'https://upload-images.jianshu.io/upload_images/25027716-74f34924da3ab19e.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
    actionbpic: 'https://upload-images.jianshu.io/upload_images/25027716-0c3cd824dd24d493.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240', 
    actioncpic: 'https://upload-images.jianshu.io/upload_images/25027716-e9b373bdba1b1af0.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
    actiondpic: 'https://upload-images.jianshu.io/upload_images/25027716-e004e0c1143c522e.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',

  }
});