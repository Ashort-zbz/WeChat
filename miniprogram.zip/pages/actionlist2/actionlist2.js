//actionlist.js
var app = getApp()
Page({
  data: {
    actionpic: 'https://upload-images.jianshu.io/upload_images/25027716-87605567285a0fcb.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
    actionapic: 'https://upload-images.jianshu.io/upload_images/25027716-ef5bd98b12c3fe4f.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
    actionbpic: 'https://upload-images.jianshu.io/upload_images/25027716-16fc1f3895e2a63a.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240', 
    actioncpic: 'https://upload-images.jianshu.io/upload_images/25027716-9951b8a352ea85d6.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',

    
  }
});
//  onLoad: function (options){
//    var newid = options.id;
//    const that = this;
//    wx.request({
//      url: "https://wapp.cq-qq.com/index/index/wappnew",
//      header: {
//        'content-type': 'application/json'
//      },
//      method: "POST",
//      data: { taken: "83f2e904ceec91d935593895e2d2dbfe", author: "goduer",id:newid },
//      complete: function (res) {
//        that.setData({
//          new: res.data
//        });
//        console.log(res.data);
//        if (res == null || res.data == null) {
//          console.error('网络请求失败');
//          return;
//        }
//      }
//    })


//  }
