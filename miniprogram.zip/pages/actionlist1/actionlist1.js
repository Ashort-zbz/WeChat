//actionlist.js
var app = getApp()
Page({
  data: {
    actionpic: 'https://upload-images.jianshu.io/upload_images/25027716-7a194671e098dbb5.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
    actionapic: 'https://upload-images.jianshu.io/upload_images/25027716-f536dfe18cf0c978.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
    actionbpic: 'https://upload-images.jianshu.io/upload_images/25027716-e078a477a105afe1.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240', 
    actioncpic: 'https://upload-images.jianshu.io/upload_images/25027716-9d30cf2607390301.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
  }
//  onLoad: function (options){
//    var newid = options.id;
//    const that = this;
//    wx.request({
//      url: "https://wapp.cq-qq.com/index/index/wappnew",
//      header: {
//        'content-type': 'application/json'
//      },
//      method: "POST",
//      data: { taken: "83f2e904ceec91d935593895e2d2dbfe", author: "goduer",id:newid },
//      complete: function (res) {
//        that.setData({
//          new: res.data
//        });
//        console.log(res.data);
//        if (res == null || res.data == null) {
//          console.error('网络请求失败');
//          return;
//        }
//      }
//    })


//  }



})