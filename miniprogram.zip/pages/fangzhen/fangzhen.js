//action.js
//获取应用实例
var app = getApp()
Page({
  data: {
    actionpic: 'https://upload-images.jianshu.io/upload_images/25027716-1d9d3f9d516f824a.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
    actionapic: 'https://upload-images.jianshu.io/upload_images/25027716-663235b3147a61dc.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
    actionbpic: 'https://upload-images.jianshu.io/upload_images/25027716-4b9099cd15d33acd.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240', 
  

  }
  
});