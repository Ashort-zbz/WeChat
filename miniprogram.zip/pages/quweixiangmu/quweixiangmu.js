//action.js
//获取应用实例
var app = getApp()
Page({
  data: {
    actionpic: 'https://upload-images.jianshu.io/upload_images/25027716-13c7e49c36faf0dc.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
    actionapic: 'https://upload-images.jianshu.io/upload_images/25027716-4c12b929964d120e.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
    actionbpic: 'https://upload-images.jianshu.io/upload_images/25027716-202473547843c9bc.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240', 
    actioncpic: 'https://upload-images.jianshu.io/upload_images/25027716-5a4765aa9853bfe2.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
    actiondpic: 'https://upload-images.jianshu.io/upload_images/25027716-44ca678c230d78b1.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
    actionepic: 'https://upload-images.jianshu.io/upload_images/25027716-bc1041265104d74a.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
    actionfpic: 'https://upload-images.jianshu.io/upload_images/25027716-859c636b99f8a0ca.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
    actiongpic: 'https://upload-images.jianshu.io/upload_images/25027716-ba5c2c6754d0507e.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
    actionhpic: 'https://upload-images.jianshu.io/upload_images/25027716-1af5689afa496507.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240',
  }
});