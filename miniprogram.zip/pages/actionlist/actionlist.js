//actionlist.js
var app = getApp()
Page({
 data:{
   new:[]
 },



//  onLoad: function (options){
//    var newid = options.id;
//    const that = this;
//    wx.request({
//      url: "https://wapp.cq-qq.com/index/index/wappnew",
//      header: {
//        'content-type': 'application/json'
//      },
//      method: "POST",
//      data: { taken: "83f2e904ceec91d935593895e2d2dbfe", author: "goduer",id:newid },
//      complete: function (res) {
//        that.setData({
//          new: res.data
//        });
//        console.log(res.data);
//        if (res == null || res.data == null) {
//          console.error('网络请求失败');
//          return;
//        }
//      }
//    })


//  }



})